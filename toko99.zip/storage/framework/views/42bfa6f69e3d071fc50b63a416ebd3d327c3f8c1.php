
<?php $__env->startSection('container'); ?>
<div class="col-12">
<?php if(session()->has('error')): ?>
<div class="alert alert-danger text-center" role="alert">
<?php echo e(session('error')); ?>

</div>
<?php endif; ?>
</div>
<div class="alert alert-warning" role="alert">
  <p><i class="bi bi-check-circle"></i>  <Strong>Input Data Training! </Strong>mengunakan dua jenis inputan yaitu data penjualan dari file Excel berisi informasi id_produk, keterangan, bulan, dan jumlah penjualan, serta data langsung dari sistem seperti nama produk dan priode.. </p>
</div>
<div class="row">

<div class="col-md-6">
<form action="importcontroller" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                <label for="training" class="form-label">Input Data (Excel) </label><br>
    <input type="file" name="training" class="form-control training <?php $__errorArgs = ['training'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('training')); ?>" name="training" required>
    <?php $__errorArgs = ['training'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>;
    <div class="invalid-feedback">
    <?php echo e($message); ?>

</div>
   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-save"></i> Simpan</button>
            </form>
        </div>

        <div class="col-md-6">
            <form action="/training" method="post">
               <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="idproduk">Input Produk :</label>
                    <select class="form-select form-control idproduk <?php $__errorArgs = ['idproduk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('idproduk')); ?>" name="idproduk" required>
                    
  <option selected>Pilih Produk</option>
  <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($produk->id); ?>"><?php echo e($produk->nama_produk); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php $__errorArgs = ['nilaiX'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>;
                    <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                  <label for="keterangan">Priode</label>
                  <input type="month" name="keterangan" class="form-control keterangan <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('keterangan')); ?>" id="keterangan" required>
                  <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>;
                  <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Tambahkan elemen input dan elemen form lainnya untuk Form 2 -->
                <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-save"></i> Simpan</button>
            </form>
        </div>
        </div>


<br>
<div class="container">
<div class="row">
    <div class="col-lg-12">
   
   
 <h5> Nama Produk : <strong> <?php echo e($nama_produk); ?></strong> </h5>



<table class="table"id="tabel">
  <thead >
    <tr>
      <th scope="col">No</th>
      <th scope="col">Keterangan</th>
      <th scope="col">Bulan</th>
      <th scope="col">Jumlah Penjualan</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->iteration); ?></th>
      <td><?php echo e(date('F-Y',strtotime($training->keterangan))); ?></td>
      <td><?php echo e($training->bulan); ?></td>
      <td><?php echo e($training->jml_penjualan); ?></td>
      <td>
        <a href="/training/<?php echo e($training->id); ?>/edit" class="btn btn-primary btn-sm"><i class="bi bi-pencil-square"></i></a>
      
        
        <form action="/training/<?php echo e($training->id); ?>"method="post" class="d-inline">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger btn-sm"
                                            onclick="return confirm('Yakin Ingin Hapus')"><i
                                                class="bi bi-trash"></i></button>
                                    </form>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<div>
<div>
<a href="/regresilinier" class="btn btn-primary"><i class="bi bi-arrow-repeat"></i>Proses</a>
<br>
<br>
<h5 class="text-center mb-4">Proses Perhitungan Regresi Linier Sederhana</h5>
<div class="alert alert-secondary" role="alert">
Rumus perhitungan Regresi Linear Sederhana adalah: <strong>𝑌=𝑎+𝑏𝑋</strong> <br>
Dimana : <br>
Y = Variabel dependen <br>
X = Variabel independen <br>
a = Konstanta / Intercept <br> 
b = Koefisien regresi / Slope <br>
Dengan : <br>
<img src="/img/rumusA.png" alt="rumusA">
<p> dengan y adalah kuantiti penjualan, x adalah periode penjualan atau bulan penjualan, a adalah konstanta yang menunjukan besarnya nilai y apabila x = 0, dan b adalah besaran perubahan nilai y</p>
</div>
  <div class="row">
    <div class="col-lg-12">
<table class="table "id="regresilinier">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Bulan(X)</th>
      <th scope="col">Jumlah Penjualan(Y)</th>
      <th scope="col">X^2</th>
      <th scope="col">Y^2</th>
      <th scope="col">XY</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $regresiliniers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regresilinier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->iteration); ?></th>
      <td><?php echo e($regresilinier->X); ?></td>
      <td><?php echo e($regresilinier->Y); ?></td>
      <td><?php echo e($regresilinier->Xpangkat2); ?></td>
      <td><?php echo e($regresilinier->Ypangkat2); ?></td>
      <td><?php echo e($regresilinier->XY); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<br>

<?php $__currentLoopData = $persamaanregresi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persamaanregresi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="alert alert-success" role="alert">
  <h4 class="alert-heading">Persamaan Regeresi : <strong>Y=a+bx </strong></h4>
  
  Hasil perhitungan di atas menggunakan persamaan regresi linier sederhana menghasilkan nilai A sebesar <strong><?php echo e($persamaanregresi->a); ?></strong> dan nilai B sebesar <strong><?php echo e($persamaanregresi->b); ?> </strong> .
  <hr>
  <p class="mb-0">Berdasarkan perhitungan diatas maka di perolehlah persamaan regresinya yaitu : <strong>Y=<?php echo e($persamaanregresi->a); ?></strong> + <strong><?php echo e($persamaanregresi->b); ?> X</strong>.Nilai Persamaan ini nantinya akan di jadikan sebagai acuan untuk memprediksi jumlah penjualan produk pada bulan atau priode berikutnya</p>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toko99\resources\views/training/index.blade.php ENDPATH**/ ?>