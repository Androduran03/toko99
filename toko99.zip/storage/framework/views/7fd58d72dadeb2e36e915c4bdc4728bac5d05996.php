
<?php $__env->startSection('container'); ?>

<div class="col-6">
<?php if(session()->has('error')): ?>
<div class="alert alert-danger" role="alert">
<?php echo e(session('error')); ?>

</div>
<?php endif; ?>
</div>


<div class="container">
<form action="/training/<?php echo e($training->id); ?>" method="post">
  <?php echo csrf_field(); ?>
  <?php echo method_field('put'); ?>
  <div class="mb-3 row">
    <label for="bulan" class="col-sm-2 col-form-label">Bulan</label>
    <div class="col-sm-10">
      <input type="number" min="1" class="form-control" id="bulan"name="bulan"value="<?php echo e($training->bulan); ?>"required>
    </div>
  </div>
 

  <div class="mb-3 row">
    <label for="jml_penjualan" class="col-sm-2 col-form-label">jml_penjualan</label>
    <div class="col-sm-10">
      <input type="number" min="1" class="form-control" id="jml_penjualan"name="jml_penjualan"value="<?php echo e($training->jml_penjualan); ?>"required>
    </div>
  </div>
  <div class="mb-3 row">
    <label for="keterangan" class="col-sm-2 col-form-label">Keterangan</label>
    <div class="col-sm-10">
      <input type="month" min="1" class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> ? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="keterangan"name="keterangan"value="<?php echo e(old('keterangan')?old('keterangan'):$training->keterangan); ?>"required>
      <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="is-invalid">
        <?php echo e($message); ?>

      </div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      
    </div>
  </div>
  <div class="mb-3 row">
    <button class="btn btn-primary">Simpan</button>
    </div>
  </div>
  </div>
  </form>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toko99\resources\views/training/edit.blade.php ENDPATH**/ ?>