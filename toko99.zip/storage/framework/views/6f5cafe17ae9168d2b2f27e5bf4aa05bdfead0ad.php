 <!-- Sidebar -->
 <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
    <!-- <div class="sidebar-brand-icon ">
       <img src="/img/logo.png" alt="" width="50" height="50">
    </div> -->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>

    <div class="sidebar-brand-text mx-3">Administrator</div>
    <?php else: ?>
    <div class="sidebar-brand-text mx-3">Kasir Toko</div>
    <?php endif; ?>
</a>

<!-- Divider -->
<hr class="sidebar-divider my-0">

<!-- Nav Item - Dashboard -->
<li class="nav-item">
    <a class="nav-link" href="home">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>DASHBOARD</span></a>
</li>





<!-- Divider -->

<hr class="sidebar-divider">
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>


           
<li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="bi bi-database-add"></i>
                    <span>DATA MASTER</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        
                        <a class="collapse-item <?php echo e(Request::is('produk') ? 'active' : ''); ?>" href="/produk">Data Produk</a>
                        <a class="collapse-item <?php echo e(Request::is('transaksi') ? 'active' : ''); ?>" href="/transaksi">Data Transaksi</a>
                        <a class="collapse-item <?php echo e(Request::is('user') ? 'active' : ''); ?>" href="/user">Data User</a>
                    </div>
                </div>
            </li>

            <hr class="sidebar-divider">
<li class="nav-item <?php echo e(Request::is('training') ? 'active' : ''); ?>">
    <a class="nav-link " href="/training">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>REGRESI LINIER</span></a>
</li>
<li class="nav-item <?php echo e(Request::is('prediksi') ? 'active' : ''); ?>">
    <a class="nav-link " href="/prediksi">
    <i class="bi bi-graph-up-arrow"></i>
        <span>PREDIKSI</span></a>
    </li>
    <li class="nav-item <?php echo e(Request::is('presentase') ? 'active' : ''); ?>">
        <a class="nav-link" href="/presentase">
        <i class="bi bi-percent"></i>
            <span>AKURASI</span></a>
    </li>
    <li class="nav-item <?php echo e(Request::is('laporan') ? 'active' : ''); ?>">
        <a class="nav-link " href="/laporan">
        <i class="bi bi-printer"></i>
            <span>LAPORAN</span></a>
        </li>
        <hr class="sidebar-divider d-none d-md-block">
            <?php else: ?>
<li class="nav-item <?php echo e(Request::is('transaksi') ? 'active' : ''); ?>">
    <a class="nav-link " href="/transaksi">
    <i class="bi bi-cash-coin"></i>
        <span>DATA TRANSAKSI</span></a>
    </li>
    <li class="nav-item <?php echo e(Request::is('laporan') ? 'active' : ''); ?>">
        <a class="nav-link " href="/laporan">
        <i class="bi bi-printer"></i>
            <span>LAPORAN</span></a>
        </li>
        <hr class="sidebar-divider d-none d-md-block">
     <?php endif; ?>
       
<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul>
<!-- End of Sidebar --><?php /**PATH C:\xampp\htdocs\toko99\resources\views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>