
<?php $__env->startSection('container'); ?>
<div class="col-6">
<?php if(session()->has('error')): ?>
<div class="alert alert-danger" role="alert">
<?php echo e(session('error')); ?>

</div>
<?php endif; ?>
</div>


<div class="container">
    <div class="row">
        <div class="col-md-6">
            <form action="/prediksi/<?php echo e($prediksi->id); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('put'); ?>
                <div class="form-group">
                  <label for="testing">Edit Bulan( Nilai X)</label>
                  <input type="number" min="0" name="testing" class="form-control testing <?php $__errorArgs = ['testing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('testing')? old('testing'):$prediksi->bulan); ?>" id="testing" required>
                  <?php $__errorArgs = ['testing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>;
                  <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                  <label for="keterangan">Keterengan</label>
                  <input type="month" name="keterangan" class="form-control keterangan <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('keterangan')? old('keterangan'):$prediksi->keterangan); ?>" id="keterangan" required>
                  <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>;
                  <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-save"></i> Simpan</button>
            </form>
        </div>
    </div>
</div>
<br>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toko99\resources\views/prediksi/edit.blade.php ENDPATH**/ ?>