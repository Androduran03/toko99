
<?php $__env->startSection('container'); ?>
<div class="col-6">
<?php if(session()->has('error')): ?>
<div class="alert alert-danger" role="alert">
<?php echo e(session('error')); ?>

</div>
<?php endif; ?>
</div>


<div class="container">
    <div class="row">
        <div class="col-md-6">
            <form action="/testing" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nama1">Input Bulan(excel):</label>
                  <input type="file" name="testing" class="form-control testing <?php $__errorArgs = ['testing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('testing')); ?>" id="testing">
                  <?php $__errorArgs = ['testing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>;
                  <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-save"></i> Simpan</button>
            </form>
        </div>
        <div class="col-md-6">
            <form action="/prediksi" method="post">
               <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nama2">Input Bulan (Nilai X) :</label>
                    <input type="number" min="0" name="bulan" class="form-control bulan <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('bulan')); ?>" name="bulan" required>
                    <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>;
                    <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                  <label for="keterangan">Keterengan</label>
                  <input type="month" name="keterangan" class="form-control keterangan <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('keterangan')); ?>" id="keterangan" required>
                  <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>;
                  <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Tambahkan elemen input dan elemen form lainnya untuk Form 2 -->
                <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-save"></i> Simpan</button>
            </form>
        </div>
    </div>
</div>
<br>
<br> <br>
<table class="table"id="tabel">
  <thead >
    <tr>
      <th scope="col">No</th>
      <th scope="col">Keterangan</th>
      <th scope="col">Bulan</th>
      <th scope="col">Prediksi</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $prediksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prediksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->iteration); ?></th>
      <td><?php echo e(date('F-Y',strtotime($prediksi->keterangan))); ?></td>
      <td><?php echo e($prediksi->bulan); ?></td>
      <td>?</td>
      
      <td>
        <a href="/prediksi/<?php echo e($prediksi->id); ?>/edit" class="btn btn-primary btn-sm"><i class="bi bi-pencil-square"></i></a>
      
        <form action="/prediksi/<?php echo e($prediksi->id); ?>"method="post" class="d-inline">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger btn-sm"
                                            onclick="return confirm('Yakin Ingin Hapus')"><i
                                                class="bi bi-trash"></i></button>
                                    </form>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<a href="/prosesprediksi"class="btn btn-primary "><i class="bi bi-arrow-repeat"></i>Proses</a>

<br>
<br>
<table class="table"id="transaksi">
  <thead >
    <tr>
      <th scope="col">No</th>
      <th scope="col">Keterangan</th>
      <th scope="col">Bulan</th>
      <th scope="col">Prediksi</th>
     
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $prediksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prediksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($prediksi->jml_penjualan > 0): ?>
    <tr>
      <th scope="row"><?php echo e($loop->iteration); ?></th>
      <td><?php echo e(date('F-Y',strtotime($prediksi->keterangan))); ?></td>
      <td><?php echo e($prediksi->bulan); ?></td>
      <td><?php echo e($prediksi->jml_penjualan); ?></td>
    </tr>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<br>
<a href="/grafik" class="btn btn-primary">Lihat Grafik</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toko99\resources\views/prediksi/index.blade.php ENDPATH**/ ?>