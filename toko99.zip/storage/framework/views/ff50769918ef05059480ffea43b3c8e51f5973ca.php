
<?php $__env->startSection('container'); ?>

<table class="table"id="naivebayes">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama Barang</th>
      <th scope="col">Jumlah Stok</th>
      <th scope="col">Jumlah Laku</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $naivebayess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $naivebayes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->iteration); ?></th>
      <td><?php echo e($naivebayes->nama_brg); ?></td>
      <td><?php echo e($naivebayes->jml_stok); ?></td>
      <td><?php echo e($naivebayes->jml_laku); ?></td>
      <td><?php echo e($naivebayes->status); ?></td>
      
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<h4>Tentukan Data Testing</h4>
<div class="col-6">
    <form action="testingnaivebayes" method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3 row">
            <label for="testingnaivebayes" class="col-sm-2 col-form-label"required>Data Testing</label>
            <div class="col-sm-10">
                <input type="number" min="1" class="form-control" name="testingnaivebayes" id="testingnaivebayes">
            </div>
        </div>
        <div class="mb-3 row">
           <button type="submit" class=" btn btn-primary btn-sm">Simpan</button>
        </div>
    </form>
</div>
<br><br>
<table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama Barang</th>
      <th scope="col">Jumlah Stok</th>
      <th scope="col">Jumlah Laku</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>
    <br>
    <?php $__currentLoopData = $testings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->iteration); ?></th>
      <td><?php echo e($testing->nama_brg); ?></td>
      <td><?php echo e($testing->jml_stok); ?></td>
      <td><?php echo e($testing->jml_laku); ?></td>
      <td><?php echo e($testing->status); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toko99\resources\views/naivebayes/index.blade.php ENDPATH**/ ?>