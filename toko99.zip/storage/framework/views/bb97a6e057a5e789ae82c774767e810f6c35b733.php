
    
    <h1>Laporan Penjualan</h1>
    <p>Periode: <?php echo e(date('F-Y',strtotime($keterangan))); ?></p>
    <?php
    $totalPrice = 0;
?>
    <table class="table" id="table">
        <thead>
        <tr>
      <th scope="col">No</th>
      <th scope="col">Keterangan</th>
      <th scope="col">Nama Produk</th>
      <th scope="col">Harga/pc</th>
      <th scope="col">Jml Stok</th>
      <th scope="col">jml Beli</th>
      <th scope="col">jml Harga</th>
    </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($sale->keterangan); ?></td>
                    <td><?php echo e($sale->nama_produk); ?></td>
                    <td><?php echo e($sale->harga); ?></td>
                    <td><?php echo e($sale->produk->jml_stok); ?></td>
                    <td><?php echo e($sale->jml_beli); ?></td>
                    <td><?php echo e($sale->jml_harga); ?></td>
                </tr>
                <?php
                $totalPrice += $sale->jml_harga; // Menambahkan harga produk ke total
            ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
        </tbody>
    </table>
 <p> Jumlah Uang
 Rp.<?php echo e(number_format($totalPrice)); ?>

 </p>   
    <button onclick="window.print()">Cetak Laporan</button>
    
   <?php /**PATH C:\xampp\htdocs\toko99\resources\views/laporan/tampil.blade.php ENDPATH**/ ?>