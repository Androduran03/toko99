
<?php $__env->startSection('container'); ?>
<div class="col-6">
<?php if(session()->has('gagal')): ?>
<div class="alert alert-danger" role="alert">
 
<?php echo e(session('gagal')); ?>

</div>
<?php endif; ?>
</div>
<div class="container">
    
<table class="table" id="regresilinier">
  <thead>
    <tr>
    <th scope="col">No</th>
      <th scope="col">Keterangan</th>
      <th scope="col">Bulan(X)</th>
      <th scope="col">Jml Penjualan(Y)</th>
      <th scope="col">Prediksi(Y')</th>
      <th scope="col">Y-Y'</th>
      <th scope="col">(Y-Y')^2</th>
      <th scope="col">((Y-Y')/Y)</th>
     
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $presentases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presentase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->iteration); ?></th>
      <td><?php echo e(date('F-Y',strtotime($presentase->keterangan))); ?></td>
      <td><?php echo e($presentase->X); ?></td>
      <td><?php echo e($presentase->Y); ?></td>
      <td>?</td>
      <td>?</td>
      <td>?</td>
      <td>?</td>
      
      
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<a href="/prosespresentase"class="btn btn-primary "><i class="bi bi-arrow-repeat"></i>Proses</a>

<br>
<br>
<table class="table"id="transaksi">
  <thead>
    <tr>
    <th scope="col">No</th>
      <th scope="col">Keterangan</th>
      <th scope="col">Bulan(X)</th>
      <th scope="col">Jml Penjualan(Y)</th>
      <th scope="col">Prediksi(Y')</th>
      <th scope="col">Y-Y'</th>
      <th scope="col">(Y-Y')^2</th>
      <th scope="col">((Y-Y')/Y)</th>
     
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $presentases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presentase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($presentase->prediksi>0): ?>
    <tr>
      <th scope="row"><?php echo e($loop->iteration); ?></th>
      <td><?php echo e(date('F-Y',strtotime($presentase->keterangan))); ?></td>
      <td><?php echo e($presentase->X); ?></td>
      <td><?php echo e($presentase->Y); ?></td>
      <td><?php echo e($presentase->prediksi); ?></td>
      <td><?php echo e($presentase->MAD); ?></td>
      <td><?php echo e($presentase->MSE); ?></td>
      <td><?php echo e($presentase->MAPE); ?></td>
    </tr>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<br> 
<?php $__currentLoopData = $hasilpresentases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasilpresentase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($hasilpresentase!=null): ?>
<div class="alert alert-success" role="alert">
  <h4 class="alert-heading">Hasil!</h4>
 
  <p>Hasil dari prediksi untuk penjualan <strong><?php echo e($namaproduk?$namaproduk:'Barang Tidak Di Kenal!'); ?></strong> pada Toko 99  menggunakan Metode  Regresi Linear Sederhana adalah sebagai berikut: <br>

1.Mean Absolute Deviation (MAD): <strong><?php echo e($hasilpresentase->hasilMAD); ?></strong>  <br>
2.Mean Squared Error (MSE): <strong><?php echo e($hasilpresentase->hasilMSE); ?></strong> <br>
3.Mean Absolute Percentage Error (MAPE): <strong><?php echo e($hasilpresentase->hasilMAPE); ?></strong> 
</p>
  <hr>
  <h5>Kesimpulan:</h5>
  <?php if($hasilpresentase->hasilMAPE < 0.1): ?>
  <p>Berdasarkan nilai MAPE yang diperoleh, dapat disimpulkan bahwa MAPE tersebut berada dalam kategori <strong>TINGGI</strong>.</p>
  
  <?php elseif($hasilpresentase->hasilMAPE > 0.1 && $hasilpresentase->hasilMAPE <= 0.2): ?>
  <p>Berdasarkan nilai MAPE yang diperoleh, dapat disimpulkan bahwa MAPE tersebut berada dalam kategori <strong>BAIK</strong>.</p>
 
  <?php elseif($hasilpresentase->hasilMAPE > 0.2 && $hasilpresentase->hasilMAPE <= 0.5): ?>
  <p>Berdasarkan nilai MAPE yang diperoleh, dapat disimpulkan bahwa MAPE tersebut berada dalam kategori <strong>REASONABLE</strong>.</p>
 
  <?php elseif($hasilpresentase->hasilMAPE > 0.5): ?>
  <p>Berdasarkan nilai MAPE yang diperoleh, dapat disimpulkan bahwa MAPE tersebut berada dalam kategori <strong>RENDAH</strong>.</p>
 <?php endif; ?>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toko99\resources\views/presentase/index.blade.php ENDPATH**/ ?>